from django.shortcuts import get_object_or_404, render
from django.http import HttpResponseRedirect, HttpResponse
from django.template import loader
from django.http import Http404
from .models import UserName
import json
global Ls
Ls=[]
global CheckLogoutPointer,LogoutPointer,new_index
LogoutPointer={}
CheckLogoutPointer=0
global CurrentLoginUser
CurrentLoginUser=0
global lastUserName
lastUserName=''
new_index=-1
# Create your views here.
def index(request):
    global Ls
    template = loader.get_template('classGame/index.html')
    Ls=[]
    #print('cleaned!')
    return HttpResponse(template.render({},request))

def picture_load(request,picture_file_name):
    f=open('classGame/static/classGame/assets/'+picture_file_name,'rb')
    st=f.read()
    f.close()
    return HttpResponse(st)

def Position_Get(request):
    global Ls,CheckLogoutPointer,LogoutPointer,CurrentLoginUser,new_index
    userName=request.GET['userName']
    if(userName in LogoutPointer and len(list(LogoutPointer.values()))>1):
        LogoutPointer[userName]=LogoutPointer[userName]+1
    else:
        LogoutPointer[userName]=0        
    if(len(list(LogoutPointer.values()))>1):
        if(abs(list(LogoutPointer.values())[1]-list(LogoutPointer.values())[0])>10):
            my_keys=list(LogoutPointer.keys())
            if(my_keys[0]==userName):
                deleted_userName=my_keys[1]
            else:
                deleted_userName=my_keys[0]
            if([i['name'] for i in Ls].count(deleted_userName)>0):
                LogoutPointer={}
                new_index=[i['name'] for i in Ls].index(deleted_userName)
                Ls[new_index]["y"]=str(-1)
                print(deleted_userName+' is deleted')
                CurrentLoginUser=CurrentLoginUser-1            
        if([i['name'] for i in Ls].count(userName)>0):
            my_index=[i['name'] for i in Ls].index(userName);
            Ls[my_index]["x"]=request.GET['x']
            Ls[my_index]["y"]=request.GET['y']
        else:
            d2={'name':userName,'x':request.GET['x'],'y':request.GET['y']}
            Ls.append(d2)

    encode_json=json.dumps(Ls)
    if(new_index!=-1):
        Ls.pop(new_index)
        new_index=-1
    #for i in Ls:
    #    print(i['name'])
    #print(''.join([i['name'] for i in Ls])
    return HttpResponse(encode_json)

def Login_Verification(request):
    global CurrentLoginUser
    try:
        print('name: '+request.POST['InputBox'])
    except Exception as e:
        print(e)
    if(CurrentLoginUser<2):
        login_user=UserName.objects.get(user_name=request.POST['InputBox'])
        login_user.user_state=login_user.user_state+1#login state
        login_user.save()
        CurrentLoginUser+=1
        return render(request, 'classGame/game.html',{'login_user':login_user})        
    else:
        print('CurrentLoginUserNum',CurrentLoginUser)
        return HttpResponse('Please wait for other player to quit the game')       
    #if([i['name'] for i in Ls].count(login_user.user_name)>0):
    #    new_index=[i['name'] for i in Ls].index(login_user.user_name);
    #    Ls.pop(new_index)
    #    print('cleaned!')

def Score(request):
    USERNAME=request.GET['userName']
    login_user=UserName.objects.get(user_name=USERNAME)
    login_user.user_score=login_user.user_score+10
    login_user.save()
    print(USERNAME+str(login_user.user_score))
    return HttpResponse('')
