from django.conf.urls import url

from . import views
app_name='classGame'
urlpatterns = [
    url(r'^$', views.index, name='index'),
    url(r'^Login/assets/(?P<picture_file_name>[A-Za-z]+\.png)/$',views.picture_load,name='picture_load'),
    url(r'^Login/position/$',views.Position_Get,name='Position_Get'),
    url(r'^Login/$',views.Login_Verification,name='Login_Verification'),    
    url(r'^Login/star/$',views.Score,name='Score'),    
    ]
