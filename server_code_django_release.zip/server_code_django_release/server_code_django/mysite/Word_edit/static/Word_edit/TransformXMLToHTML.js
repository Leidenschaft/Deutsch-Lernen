var transformXMLtoHtml
$(document).ready(function () {
    transformXMLtoHtml = function transformXMLtoHtml(xml) {

    }
  
});