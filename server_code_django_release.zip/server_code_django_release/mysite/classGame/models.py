from django.db import models
class UserName(models.Model):
    def __str__(self):
        return self.user_name+' '+str(self.user_score)+' '+str(self.user_state)

    user_name = models.CharField(max_length=200)
    user_score = models.IntegerField(default=0)
    user_state = models.IntegerField(default=-1) 
# Create your models here.
#from classGame.models import UserName
#UserName.objects.get(pk=2)
