//use a server to get the data in real time.
$(document).ready(function () {

var isMobile = false;
var xmlHttp = new XMLHttpRequest();
var starHttp;
    //identity check here

var game = new Phaser.Game(800, 600, Phaser.AUTO, '', { preload: preload, create: create, update: update });
function preload() {
    game.load.image('sky', "assets/sky.png");
    game.load.spritesheet('baddie', "assets/baddie.png",32,32);
    game.load.image('ground', 'assets/platform.png');
    game.load.image('star', 'assets/star.png');
    game.load.spritesheet('dude', 'assets/dude.png', 32, 48);
    var BrowersType;
    var userAgent = navigator.userAgent;
    if (userAgent.indexOf("Android") > -1) {
        //page redirection
        isMobile = true;
    }

}

var platforms;
var score = 0;
var scoreText;
var debugText;
var userName;
var slowDownSyn_synchronization = 0;
var PlayerNumber=0;
var starCreated = false;
player_list = new Array();

function addPlayer(playerName, x_pos, y_pos) {
    if (playerName == 'admin') {
        player_list[playerName] = game.add.sprite(x_pos, y_pos, 'dude');
        player_list[playerName].animations.add('left', [0, 1, 2, 3], 10, true);
        player_list[playerName].animations.add('right', [5, 6, 7, 8], 10, true);
    }
    else {
        player_list[playerName] = game.add.sprite(x_pos, y_pos, 'baddie');
        player_list[playerName].animations.add('left', [0,1], 10, true);
        player_list[playerName].animations.add('right', [2,3], 10, true);
    }

    //    player = game.add.sprite(32, game.world.height - 150, 'dude');
    //use the dic structure
    //  We need to enable physics on the player
    game.physics.arcade.enable(player_list[playerName]);

    //  Player physics properties. Give the little guy a slight bounce.
    if (playerName == userName) {
        player_list[playerName].body.bounce.y = 0.2;
        player_list[playerName].body.gravity.y = 300;
    }
    player_list[playerName].body.collideWorldBounds = true;
    PlayerNumber += 1;
    //  Our two animations, walking left and right.

}
function create() {
    //judge the device here.
    //  We're going to be using physics, so enable the Arcade Physics system
    game.physics.startSystem(Phaser.Physics.ARCADE);

    //  A simple background for our game
    game.add.sprite(0, 0, 'sky');

    //  The platforms group contains the ground and the 2 ledges we can jump on
    platforms = game.add.group();

    //  We will enable physics for any object that is created in this group
    platforms.enableBody = true;

    // Here we create the ground.
    var ground = platforms.create(0, game.world.height - 64, 'ground');

    //  Scale it to fit the width of the game (the original sprite is 400x32 in size)
    ground.scale.setTo(2, 2);

    //  This stops it from falling away when you jump on it
    ground.body.immovable = true;

    //  Now let's create two ledges
    var ledge = platforms.create(400, 400, 'ground');

    ledge.body.immovable = true;

    ledge = platforms.create(-150, 250, 'ground');

    ledge.body.immovable = true;
    userName = $("#userNameRetrive").html();
    //x_pos should be given randomly
    if(userName.length>1)
        addPlayer(userName, 100 + 600*Math.random(), game.world.height - 200);




    if (isMobile) {
        pointer_1_position = game.input.pointer1.position;//Point Object
        //event listening
    }
    else {
        cursors = game.input.keyboard.createCursorKeys();
    }
    stars = game.add.group();

    stars.enableBody = true;

    //  Here we'll create 12 of them evenly spaced apart


    scoreText = game.add.text(16, 16, 'score: 0', { fontSize: '32px', fill: '#000' });
    debugText = game.add.text(216, 16, 'Waiting for others ', { fontSize: '16px', fill: '#000' });

}
function GetResponseData() {
    if (xmlHttp.readyState == 4 && xmlHttp.status == 200 && xmlHttp.responseText.length>2) {
        var dataObj = eval("(" + xmlHttp.responseText + ")");
      //  var st = '[{"name":"admin","x":"12","y":"34"}, {"name":"\\u8d75\\u4e30","x":"56","y":"78"}]';
        for (var i = 0; i < dataObj.length; i++) {
            var d1 = dataObj[i];
            if (d1.name == userName) continue;
            else {
                if (d1.name in player_list) {
                    if (parseInt(d1.y) < 0) {
                        player_list[d1.name].kill();
                        debugText.text = d1.name + ' quited the game';
                    }
                    else {
                        player_list[d1.name].x = parseInt(d1.x);
                        player_list[d1.name].y = parseInt(d1.y);
                        game.physics.arcade.collide(player_list[d1.name], platforms);
                        var occured = game.physics.arcade.overlap(player_list[d1.name], stars, collectStar_2, null, this);
                        if (occured) {
                            debugText.text = d1.name + ' add 10 score';
                        }
                    }
                }
                else {
                    addPlayer(d1.name, parseInt(d1.x), parseInt(d1.y));
                    debugText.text = d1.name+' joins the game';
                }
            }
        }


        if (PlayerNumber == 2 && (!starCreated)) {
            for (var i = 0; i < 12; i++) {
                //  Create a star inside of the 'stars' group
                var star = stars.create(i * 70, 0, 'star');

                //  Let gravity do its thing
                star.body.gravity.y = 6;

                //  This just gives each star a slightly random bounce value
                star.body.bounce.y = 0.7;
            }
            starCreated = true;
            debugText.text = 'Game started';
        }
        xmlHttp = new XMLHttpRequest();
    }
}

function update() {
    if (userName.length > 1) {

        var hitPlatform = game.physics.arcade.collide(player_list[userName], platforms);
        game.physics.arcade.collide(stars, platforms);
        game.physics.arcade.overlap(player_list[userName], stars, collectStar, null, this);
        //  Reset the players velocity (movement)
        player_list[userName].body.velocity.x = 0;
        if (!isMobile) {
            if (cursors.left.isDown) {
                //  Move to the left
                player_list[userName].body.velocity.x = -150;

                player_list[userName].animations.play('left');
            }
            else if (cursors.right.isDown) {
                //  Move to the right
                player_list[userName].body.velocity.x = 150;

                player_list[userName].animations.play('right');
            }
            else {
                //  Stand still
                player_list[userName].animations.stop();
                if (userName == 'admin') {
                    player_list[userName].frame = 4;
                }
                else {
                    player_list[userName].frame = 2;
                }
            }

            //  Allow the player to jump if they are touching the ground.
            if (cursors.up.isDown && player_list[userName].body.touching.down && hitPlatform) {
                player_list[userName].body.velocity.y = -350;
            }
        }
        else {
            if (game.input.pointer1.isDown) {
                if (pointer_1_position.x < player_list[userName].x) {
                    player_list[userName].body.velocity.x = -150;

                    player_list[userName].animations.play('left');
                }
                else if (pointer_1_position.x > player_list[userName].x) {
                    //  Move to the right
                    player_list[userName].body.velocity.x = 150;

                    player_list[userName].animations.play('right');
                }
                if (pointer_1_position.y < player_list[userName].y && player_list[userName].body.touching.down && hitPlatform) {
                    player_list[userName].body.velocity.y = -350;
                }

            }
            else {
                //  Stand still
                player_list[userName].animations.stop();

                if (userName == 'admin') {
                    player_list[userName].frame = 4;
                }
                else {
                    player_list[userName].frame = 2;
                }
            }
            //mobile support here
        }
        slowDownSyn_synchronization += 1;
        if (slowDownSyn_synchronization == 20) {
            slowDownSyn_synchronization = 0;
            if (xmlHttp != null) {

                var url = "position?x=" + player_list[userName].x.toString() + "&y=" + player_list[userName].y.toString() + "&userName=" + userName;
                xmlHttp.open("GET", url, true);
                xmlHttp.onreadystatechange = GetResponseData;
                xmlHttp.send();
            }

        }
    }
   
}
function collectStar_2(player, star) {
    star.kill();
}
     
function collectStar(player,star) {

    // Removes the star from the screen
    
    starHttp = new XMLHttpRequest();
    if (starHttp != null) {

        var url = "star?userName="+ userName;
        starHttp.open("GET", url, true);
        starHttp.send();
    }

    star.kill();
    //send a message to serve to noggle that one star is collected.
    score += 10;
    scoreText.text = 'Score: ' + score;

}
});
