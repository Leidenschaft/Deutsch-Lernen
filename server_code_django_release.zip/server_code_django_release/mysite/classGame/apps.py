from django.apps import AppConfig


class ClassgameConfig(AppConfig):
    name = 'classGame'
