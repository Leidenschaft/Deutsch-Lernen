import os
import codecs
from lxml import etree
path=os.getcwd()
path=path+"\\templates\\Word_edit\\"
for i in range(463):
    wordurl="str(i+1)+".xml"
    print(wordurl)
    xml=codecs.open(path+"Wort\\"+wordurl,'r','utf-8')
    s=xml.read()
    s=s.encode('utf-8')
    xml.close()
    f=open(path+'Wort\\NounRenderTemplate2.xslt','rb')
    st=f.read()
    xslt_root=etree.XML(st)
    transform=etree.XSLT(xslt_root)
    doc=etree.XML(s)
    result_tree=transform(doc)
    html=codecs.open(path+"Wort\\"+wordurl.replace('xml','html'),'w',encoding='utf-8')
    st=etree.tostring(result_tree.getroot(),encoding='utf-8')
    st=st.decode('utf-8')
    st=st.replace('</head>','</head>\n{% load static %} \n')
    st=st.replace('../jquery-1.9.1.min.js"/>',"{% static 'Word_edit/jquery-1.9.1.min.js' %}\"></script>")
    st=st.replace('../js/jquery-1.9.1.min.js"/>',"{% static 'Word_edit/jquery-1.9.1.min.js' %}\"></script>")
    st=st.replace('BufferSearch.js"/>',"{% static 'Word_edit/BufferSearch.js' %}\"></script>")
    st=st.replace('snd_sfx.png',"{% static 'Word_edit/snd_sfx.png'%}")
    st=st.replace('icon16_search.png',"{% static 'Word_edit/icon16_search.png'%}")
    st=st.replace('.xml','.html')
    st=st.replace('&#10;          ../images/'+wordurl.replace("xml","jpg"),"{% static 'Word_edit/images/"+wordurl.replace("xml","jpg")+"'%}")
    html.write(st)
    html.close()
