from django.apps import AppConfig


class WordEditConfig(AppConfig):
    name = 'Word_edit'
